<?php
require 'vendor/phpmailer/phpmailer/src/Exception.php';
require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'vendor/phpmailer/phpmailer/src/SMTP.php';
session_start();
/*if(!isset($_SESSION['id'])){ //if login in session is not set
    header("Location: first_step.php");
}*/
$otp=mt_rand(1000,9999);
$_SESSION['otp']=$otp;

date_default_timezone_set('Etc/UTC');

// require 'PHPMailer/PHPMailerAutoload.php';
// use vendor\PHPMailer\PHPMailer\PHPMailer;
// use vendor\PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
echo !extension_loaded('openssl')?"Not Available":"Available";

$mail = new PHPMailer(true);
 
$mail->isSMTP();
$mail->SMTPDebug = 4;
$mail->Debugoutput = 'html';
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "anmolpardesi25@gmail.com";
$mail->Password = "zofoixurzlbcgizc";
 
$mail->setFrom = 'anmolpardesi25@gmail.com';
$mail->FromName = 'Anmol Pardesi';
$mail->addAddress('dattapolade@gmail.com', 'Datta');
 
$mail->addReplyTo('anmolpardesi25@gmail.com', 'Anmol ji');
 
$mail->WordWrap = 50;
$mail->isHTML(true);
 
$mail->Subject = 'Password Verification';
$mail->Body    = 'OTP is '.$otp;
 
if(!$mail->send()) {
   echo 'Message could not be sent.';
   echo 'Mailer Error: ' . $mail->ErrorInfo;
}
 else
 {
  echo 'Message has been sent';
 }
echo "<script>window.location.assign('otp.php');</script>"
?>