<?php

$servername = "localhost:3500";
$username = "root";
$password = "";
$dbname = "is_project";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>