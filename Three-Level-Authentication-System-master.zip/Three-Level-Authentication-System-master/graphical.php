<!DOCTYPE html>
<html>
<head>
	<title>Level 2 Authentication</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<style type="text/css">
		#container{
			margin: 150px 450px;
		}
		#red_box, #blue_box, #green_box{
			padding: 50px;
			margin-left: 20px;
			cursor: pointer;
		}
		#input{
			margin-top: 30px;
			width: 400px;
		}
		#submit{
			margin-top: 30px;
			margin-left: 150px;
		}
		#red_box{
			background-color: red;
			
		}
		#blue_box{
			background-color: blue;
		}
		#green_box{
			background-color: green;
		}
	</style>
</head>

<body>
<div class="jumbotron" style="background-color: #1a1a1a; color: white;">
<h1 style="margin-left: 20px;">Graphical Password</h1>
</div>

<div id="container">
	<button id="red_box" class="btn btn-danger" onclick="addVal('1234');"></button>
	<button id="blue_box" class="btn btn-primary" onclick="addVal('5678');"></button>
	<button id="green_box" class="btn btn-success" onclick="addVal('9101')"></button>
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
		<input type="password" class="form-control" id="input" name="graph" placeholder="Pattern Here" />
		<button class="btn btn-info" id="submit" name="submit">Save</button>
		<button class="btn btn-info" id="submi" name="submi">Check</button>
	</form>
</div>
</body>
<script type="text/javascript" src="js/jquery.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
	let rbox = document.getElementById("red_box");
	let bbox = document.getElementById("blue_box");
	let gbox = document.getElementById("green_box");
	let ifield = document.getElementById("input");
	function addVal(st) {
		let txt = ifield.value;
		txt += st;
		ifield.value = txt;
	}
	
</script>
</html>
<?php
include 'connection.php';

session_start();
/*if(!isset($_SESSION['id'])){
    header("Location: first_step.php");
}*/
if(isset($_POST["submit"]))
	{
		$graph=$_POST['graph'];
		$graph=md5($graph);
		$ses=$_SESSION["id"];
		
		$sql = "UPDATE details SET Graphical='$graph' WHERE id='$ses'";
		echo mysqli_query($conn, $sql);
		
		if (mysqli_query($conn, $sql)) {
		    echo '<script>alert("Graphical Password Added");</script>';
		    echo '<script type="text/javascript"> window.location = "picture_pass.php" </script>';
		} 
		
		else {
			}

		mysqli_close($conn);
		}
?>



<?php
session_start();
include 'connection.php';
/*if(!isset($_SESSION['id'])){ //if login in session is not set
    header("Location: first_step.php");
}*/
if(isset($_POST["submi"]))
	{
		$pic=$_POST['pic'];
		$pic=md5($pic);
		$ses=$_SESSION["id"];
		
		$sql = "select * from details where Picture='$pic' and id='$ses'";
		echo $sql;
		$result= mysqli_query($conn, $sql);
		if($result){
			$numerous=mysqli_num_rows($result);
		if ($numerous==0) {
		    echo '<script>alert("Successfully Login");</script>';
		    echo '<script type="text/javascript"> window.location = "picture_pass.php" </script>';
		} 
		
		else {
			   echo'<script>alert("Error: invalid picture")</script>';
			
		}

		mysqli_close($conn);
	}
 }
?>
