<!doctype html>
<html lang="us-en">

<head>
	<title>LOGIN</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" charset="UTF-8" />
	<link rel="stylesheet" href="css/font-awesome.css" type="text/css" />
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
	<style>
		#box {
			margin-left: 500px;
			margin-right: 500px;
			padding: 20px;
			background-color: #bfbfbf;
			border-radius: 5px;
			padding-left: 30px;
			padding-right: 30px;
		}

		#pic {
			height: 420px;
			width: 510px;
			margin-left: 50px;
			border-radius: 5px;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.4), 0 6px 20px 0 rgba(0, 0, 0, 0.5);
			margin-top: 20px;
		}

		.small_box {
			height: 140px;
			width: 170px;
			border-radius: 3px;
			margin-left: 10px;
			margin-top: 10px;
			padding: 0;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.4), 0 6px 20px 0 rgba(0, 0, 0, 0.5);
			overflow: hidden;
		}

		#inputb {
			margin-top: 30px;
			width: 400px;
		}

		#container {
			margin: 150px 450px;
		}

		#red_box,
		#blue_box,
		#green_box {
			padding: 50px;
			margin-left: 20px;
			cursor: pointer;
		}

		#inputb {
			margin-top: 30px;
			width: 400px;
		}

		#submit {
			margin-top: 30px;
			margin-left: 150px;
		}

		#red_box {
			background-color: red;

		}

		#blue_box {
			background-color: blue;
		}

		#green_box {
			background-color: green;
		}
	</style>
</head>

<body>



<script>
		function image_crop(){
			
			var m_left=0;
			var m_top=0;
			var i,j;
			for (i=0; i<9; i++)
			{

				m_left=0;
				console.log(i);
				console.log(m_top);
				for(j=0;j<9;j++)
				{
					var temp_id;
					temp_id=i.toString()+j.toString();
					console.log(temp_id);
					document.getElementById(temp_id).src="car.jpg";
					document.getElementById(temp_id).style.marginLeft=m_left.toString()+'px';
					document.getElementById(temp_id).style.marginTop=m_top.toString()+'px';
					m_left=m_left-170;
				}
				
				m_top=m_top-140;
			}
		}
	</script>
	
	<div class="jumbotron" style="background-color: #1a1a1a; color: white;">
		<h1 style="margin-left: 20px;">Login</h1>
	</div>
	<div class="contaier">
		<form method="post" class="form-horizontal" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
			
			<div class="form-group">
				<label class="control-label">Id:</label>
				<input type="text" class="form-control" name="Id" placeholder="Id">
			</div>
			<div class="form-group">
				<label class="control-label">Password:</label>
				<input type="password" class="form-control" name="password" placeholder="Password">
			</div>
			<div id="container">
				<div id="red_box" class="btn btn-danger" onclick="addVal('1234');"></div>
				<div id="blue_box" class="btn btn-primary" onclick="addVal('5678');"></div>
				<div id="green_box" class="btn btn-success" onclick="addVal('9101')"></div>
				<input type="password" class="form-control" id="input" name="graph" placeholder="Pattern Here" />
			</div>
			<div class="row">

			<button type="submit" class="btn btn-default" name="submit1"style="color: #000; font-weight: bold; margin-left: 0;">submit</button>
		</form>
	</div>
	</div>
			
	</div>
		
	



		<script type="text/javascript" src="js/jquery.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		<script type="text/javascript">
			let rbox = document.getElementById("red_box");
			let bbox = document.getElementById("blue_box");
			let gbox = document.getElementById("green_box");
			let ifield = document.getElementById("input");
			function addVal(st) {
				let txt = ifield.value;
				txt += st;
				ifield.value = txt;
			}

		</script>
		<script>
			function image_crop() {

				var m_left = 0;
				var m_top = 0;
				var i, j;
				for (i = 0; i < 3; i++) {

					m_left = 0;
					console.log(i);
					console.log(m_top);
					for (j = 0; j < 3; j++) {
						var temp_id;
						temp_id = i.toString() + j.toString();
						console.log(temp_id);
						document.getElementById(temp_id).src = "images/SSY_5447.jpg";
						document.getElementById(temp_id).style.marginLeft = m_left.toString() + 'px';
						document.getElementById(temp_id).style.marginTop = m_top.toString() + 'px';
						m_left = m_left - 170;
					}

					m_top = m_top - 140;
				}
			}
		</script>
		<script type="text/javascript" src="js/jquery.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
		
</body>

</html>
<?php
	
	include 'connection.php';

	if(isset($_POST["submit1"]))
	{
	  $pass=$_POST['password'];
	  $id=$_POST['Id'];
	  $graphical=$_POST["graph"];
	  if ($pass!="" and $id!="" and $graphical!="")
	  {
	    $pass=md5($pass);
		$graphical = md5($graphical);
		$sql = "select * from details where Id='$id' and Password='$pass' and graphical='$graphical'";
		$result = mysqli_query($conn, $sql);
		if ($result) {
			if(mysqli_num_rows($result)==1){
				$_SESSION['id']=$id;
				//echo '<script type="text/javascript"> window.location = "otp.php" </script>';
				//echo '<script type="text/javascript"> window.location = "mail.php" </script>';
				echo '<script type="text/javascript"> window.location = "thanks.php" </script>';
			}else {
				echo '<script>alert("Error: invalid id/password");</script>';
			}
		}
		
	  }
	}

	mysqli_close($conn);
?>